# Results

# We are open-source on Github

- The implementation done in this project was hosted as an open-source project throughout the period and will be available there for the foreseeable future.
- An implementation using reference libraries.

# We demonstrated a solution to our scenario

- Demonstrate 4 actors on one screen - Person, Police, vegvesen, government.
- Demonstrated live in front of an audience.