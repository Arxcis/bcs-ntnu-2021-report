# User Interface

Based on the requirements from chapter 3. Functional Requirements, it is now possible to say something about the User Interface in general. The main User Interface will be as implemented as a Command-line Interface. This should be obvious after reading Chapter 3, as the chapters requirements was written with a CLI in mind.

# Unix inspiration

When implementing a CLI it is a good idea to draw inspiration from the established Unix community, which has historically pushed the CLI as the primary interface when interacting with any computer for almost any task.

## **Unix PIpelines**

Many of the commands in the *did-cli*, is designed in a way to easily integrate with existing Unix tools. The most important part of this integration, is to support optionally reading input from *stdin*. Also it is important to take care in how output is written to *stdout*, to make it possible to chain commands together. This is the reason you will see that most of commands are standardized to write full *dcem*-messages to *stdout*, for easy consumption by the next command in the pipeline.

```bash
cat message.dcem | did read | grep jonas
```

## Unix Files

The standard usage *stdin* and *stdout* also makes it really easy to work with files if necessary. Below is an example of doing the exact same thing as in Section 4.1.1, but with files instead.

```bash
did read message.dcem > message.dpem
grep jonas message.dpem
```

Different Unix-workflows require the ability to use both of the methods depicted in Chapter 4.1.1 and 4.1.2, which makes it important to support both of them. A Unix user will expect any CLI to work with both FILES and PIPES.

# Commands

This section gives a short description of all available commands in the user interface and a screenshot of running the command.

## did help

- Lists all available commands.
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled.png)
    

## did init

- Creates an agent in the current directory.
- The command creates a new `.did/`directory, inside your working directory.
- Your agents DID will be returned to `stdout` when running this command.
- The command is idempotent.
- *did init* bahaves almost identical to *git init.* This is intentional.

![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%201.png)

## did doc

- Prints the did-document, controlled by the did agent.
- Since the did-agent uses did-key as it's underlying did-method, the did-document is generated from the public-private keypair.
- Another way to describe this is that did-key is self-resolving - the did-document is resolved directly from the did.
- This is a limitation of the did-key method, and how it is specified.
- Once created, the did-document pinned to a did-key did, is not possible to edit.
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%202.png)
    

## did dids

- List all dids stored in the agent.
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%203.png)
    

## did did <didname>

- Show the did of a single `<didname>`.
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%204.png)
    

## did connect <didname> <did>

- `did connect` connects a `<didname>` to `<did>`
- `did connect` gives a `<did>` a `<didname>`.
- The `<didname>` is used in other commands, as an easy way to refer to another agent's `<did>`.
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%205.png)
    

## did write <didname> <message>

- Wraps a user defined message inside a `<dcem>`envelope.
- Sets the `to`header of the `<dcem>` to the underlying `<did>` refered to by the `<didname>`.
- Gives the message a new globally unique `id` - GUID.
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%206.png)
    

## did read <dcem>

- Unwraps an `<dcem>` message from `stdin` or from `<dcem>`arg.
- Prints the plaintext body of the message.

- *Example - Read plain message:*
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%207.png)
    

- *Example - Read Verifiable Credential of type Passport*
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%208.png)
    

- Example - Read Verifiable Presentation of type Passport
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%209.png)
    

## did issue <CredentialType> <didname>

- Issues a verifiable credential addressed to the `did` of `<didname>`:
- Issues one of 4 `<CredentialType>`s:
    - Passport
    - DriversLicense
    - TrafficAuthority
    - LawEnforcer
- Example of issuing a Verifiable Credential of type Passport
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%2010.png)
    

## did hold <dcem>

- Holds <dcem> and prints it to stdout
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%2011.png)
    

## did present <didname> <dcem>

- Prints a Verifiable Presentation to stdout, with <dcem> as it's content
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%2012.png)
    

## did verify <issuer didname> <subject didname> <dcem>

- Prints `<dcem>` to `stdout`, if, and only if, verification succeeds.
- Example  - where verification succeeds:
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%2013.png)
    
- Example - where verification fails:
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%2014.png)
    

## did messages

- List all didcomm messages stored in the wallet.
- Messages are added to the wallet when using the `did hold` command.
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%2015.png)
    

## did message <message id>

- Show the contents of a single didcomm message based on the given `<message id>`.
    
    ![Untitled](User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea/Untitled%2016.png)
    

# Intentional limitations of the CLI

- None of the commands have any optional-arguments - e.g `-option=<arg>`. This is to keep program logic as simple as possible. If the CLI was intended for a broader audicene with multiple use-cases, options may be added. This CLI is a special purpose CLI, intended to solve a specific use-case, namely the specific proof-of-concept from the problem statement. This is why optional-arguments was not prioritized.
- Options are much harder to parse correctly than fixed size positional arguments.
- None of the commands required variable length arguments, which made the implementation easier.
- None of the commands have filepath arguments. The user is expected to use `cat <filepath>` to read the contents of a file, which is then fed into a positional argument of one of the commands. Example: `did read \\$(cat ../message.dcem)` vs `did read ../message.dcem`. This was done to simplify implementation.