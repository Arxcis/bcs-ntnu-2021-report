# Snorre

Role: Project owner, tech supervisor