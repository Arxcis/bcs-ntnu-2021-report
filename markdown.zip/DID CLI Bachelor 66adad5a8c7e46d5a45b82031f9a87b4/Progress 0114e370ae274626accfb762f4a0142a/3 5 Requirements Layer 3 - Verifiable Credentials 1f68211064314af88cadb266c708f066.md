# 3.5 Requirements Layer 3 - Verifiable Credentials

Date: October 25, 2021