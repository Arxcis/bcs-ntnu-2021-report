# 3.2. BDD-style Requirements

Date: October 25, 2021