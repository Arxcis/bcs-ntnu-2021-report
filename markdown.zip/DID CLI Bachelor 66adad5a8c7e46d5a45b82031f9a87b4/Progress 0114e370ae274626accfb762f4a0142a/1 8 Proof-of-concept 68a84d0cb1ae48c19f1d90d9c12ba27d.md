# 1.8 Proof-of-concept

Date: October 15, 2021