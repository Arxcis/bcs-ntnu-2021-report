# 5.3 External libraries

Date: November 5, 2021