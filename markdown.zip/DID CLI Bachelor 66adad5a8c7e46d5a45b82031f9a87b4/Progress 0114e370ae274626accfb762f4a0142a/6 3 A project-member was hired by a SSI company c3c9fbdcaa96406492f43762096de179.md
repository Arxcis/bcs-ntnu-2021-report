# 6.3 A project-member was hired by a SSI company

Date: November 5, 2021 → November 12, 2021