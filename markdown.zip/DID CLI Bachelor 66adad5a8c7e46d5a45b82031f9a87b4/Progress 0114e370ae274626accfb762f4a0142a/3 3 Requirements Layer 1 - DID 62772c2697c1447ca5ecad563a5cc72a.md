# 3.3 Requirements Layer 1 - DID

Date: October 25, 2021