# 1.7 Project Scope

Date: October 15, 2021