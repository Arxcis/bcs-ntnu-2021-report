# 7.1 The Path to Self-Sovereign Identity

Date: November 5, 2021 → November 12, 2021