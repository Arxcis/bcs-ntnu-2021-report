# 5. Architecture

Date: October 26, 2021 → November 5, 2021