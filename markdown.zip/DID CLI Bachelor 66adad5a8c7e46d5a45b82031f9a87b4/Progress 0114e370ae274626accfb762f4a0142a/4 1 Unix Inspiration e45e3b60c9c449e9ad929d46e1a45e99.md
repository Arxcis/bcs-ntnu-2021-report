# 4.1 Unix Inspiration

Date: October 25, 2021