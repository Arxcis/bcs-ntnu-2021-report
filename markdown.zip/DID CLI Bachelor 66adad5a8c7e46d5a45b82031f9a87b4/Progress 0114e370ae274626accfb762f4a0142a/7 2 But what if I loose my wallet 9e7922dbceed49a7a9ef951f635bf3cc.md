# 7.2 But what if I loose my wallet?

Date: November 5, 2021 → November 12, 2021