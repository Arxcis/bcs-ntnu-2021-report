# 4.3 Intentional limitations of the CLI

Date: October 25, 2021 → October 29, 2021