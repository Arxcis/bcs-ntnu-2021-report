# 7.4 Incumbents at risk

Date: November 19, 2021 → November 26, 2021