# 8.2 Future work

Date: November 19, 2021 → November 26, 2021