# 2.3 Weekly meetings

Date: October 15, 2021