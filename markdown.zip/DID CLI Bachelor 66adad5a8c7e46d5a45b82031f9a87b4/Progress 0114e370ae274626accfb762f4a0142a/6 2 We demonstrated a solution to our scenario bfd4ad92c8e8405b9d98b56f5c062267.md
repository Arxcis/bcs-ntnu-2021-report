# 6.2 We demonstrated a solution to our scenario

Date: November 5, 2021 → November 12, 2021