# 3.4 Requirements Layer 2 - DIDComm

Date: October 25, 2021