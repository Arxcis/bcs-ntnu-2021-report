# 7.3 Interoperability worries

Date: November 12, 2021 → November 19, 2021