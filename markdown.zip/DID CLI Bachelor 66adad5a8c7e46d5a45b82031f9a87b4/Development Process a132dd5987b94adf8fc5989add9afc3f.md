# Development Process

# Kanban

To keep track of tasks we used a Kanban board.

![Untitled](Development%20Process%20a132dd5987b94adf8fc5989add9afc3f/Untitled.png)

## The 5 columns of the Kanban board

1.  **Inbox:** List of tasks which have been thought of, but is lacking details like what needs to be done and when the implementation is supposed to happen. Tasks in backlog are created whenever someone feels like it. There are no requirements to put something in the backlog. The treshold should be as low as possible. Eqaully, the treshold for deleting a backlog-task should be equally low.
2.  **Backlog:** List of tasks that are planned to be implemented in the near future, and have enough details ironed out to make it possible to start the implementation. Tasks are moved from `Inbox` to `Backlog`:
    1. After being discussed in the weekly domain-experts meeting.
    2. item or after an ad-hoc meeting dedicated to discussing a specific task.
    3. item or after the developer has researched/learned something which makes a task "obviously implementable". If a developer does this, it should be clearly communicated in the next weekly domain-experts meeting.
3. **In Progress**: List of tasks that are in progress. A developer have written words, code or done something else. These tasks should ideally be linked to an open Pull Request on Github with a WIP label on it.
4. **In Review:** List of tasks where the developer has implemented the task, and is waiting to get a stamp of approval from a second pair of eyes. Approval could be given by the client, supervisor or any of the domain experts. The developer will request review from the specific person which is considered best suited to review the pull request. This specific person will be notified about this on Discord, and via email if necessary.
5. **Done:** List of task where the pull request linked to the task has been approved and merged into the main branch of the git source tree.

<div style="page-break-after: always; visibility: hidden">
\pagebreak
</div>

# Github source code

All source code is hosted at [https://github.com/DIN-foundation/bcs-ntnu-2021/](https://github.com/DIN-foundation/bcs-ntnu-2021/).

## Source code of DID-CLI

All DID-CLI source code was kept in a public open-source Github-repo, during the entire development. This made it easier to collaborate on the source code, because all participants had public access to all the work that was being done, from day one.

![Untitled](Development%20Process%20a132dd5987b94adf8fc5989add9afc3f/Untitled%201.png)

## Source code of Playground example

Before implementing the DID-CLI, a lot of experimentation had to be done. This was done to learn, and iterate on smaller projects, before beginning on the big one. Most of the projects in the playground-folder are useless, but they served an important role as learning exercises.

![Untitled](Development%20Process%20a132dd5987b94adf8fc5989add9afc3f/Untitled%202.png)

## Source code of Report

Even the report was initially developed on Github, in the same repo as DID-CLI and playground.

![Untitled](Development%20Process%20a132dd5987b94adf8fc5989add9afc3f/Untitled%203.png)

\pagebreak

# Weekly meetings

## Weekly meeting notes on Github

Each meeting has a meeting note document attached to it, noting down the attendees
and a log of what was discussed during the meeting and can be found here [https://github.com/DIN-Foundation/bcs-ntnu-2021/tree/main/meetings](https://github.com/DIN-Foundation/bcs-ntnu-2021/tree/main/meetings).

![Untitled](Development%20Process%20a132dd5987b94adf8fc5989add9afc3f/Untitled%204.png)

## Domain Experts Weekly - Tuesdays @ 12:30

- **Agenda:** Discussed questions related to the problem-domain SSI and software engineering. Demonstrated and validated product iterations.
- **Attendees**: Jonas, Snorre, Mariusz, Abylay.
- **Where:** Google Meet

## Academic Supervisor Weekly - Wednesdays @ 14:00

- **Agenda:** Discussed everything related to academic writing and how to organize the project's workflow.
- **Attendees:** Jonas, Deepti
- **Where**: Microsoft Teams

## A virtual bachelor

Due to the pandemic, all meetings were virtual. The team never got a chance to meet in real life during the project period. Even the final presentation of the bachelor thesis was given over MS teams. There is no doubt that this had a negative effect on the motivation of the student involved in this bachelor thesis. 

\pagebreak

# Community servers

**DIN Discord server**

During the development process many topics were discussed inside the DINs Discord server. This is were most of the written technical conversations between the team members took place.

**DIF Slack server**

After a long application process which started here [https://identity.foundation/join/](https://identity.foundation/join/) , I was finally accepted as a member of the DIF foundation and allowed access to their sacred Slack server. Here you can find many of the authors and developers of the different SSI standards, which was an invaluable resource during the project.

\pagebreak

# Toggl Time Tracking

Tracking the hours was done in Toggl from day 1 (week 5), and throughout the project (end week 20). The hours were tagged with the following 6 categories:

- **Meeting:** Toggled when participating in a live meeting, or when writing meeting notes.
- **Organizing:** Toggled when organizing meetings and creating and updating Kanban tasks.
- **Writing**: Toggled when writing the  bachelor report.
- **Coding**: Toggled when coding in the playground mini-projects, or the DID-CLI main project.
- **Researching**: Toggled when reading specifications, papers, blog-posts, discussing with experts on the DIF and DIN slack/Discord channels, watching videos, reading previous bachelor reports, reading books, and more...
- **Lecture**: Toggled when participating in weekly lectures in the profprog-course, or one of the "lightning lectures" related to the bachelor-course.

*Example 1: Toggl live calendar*

![Untitled](Development%20Process%20a132dd5987b94adf8fc5989add9afc3f/Untitled%205.png)

*Example 2: Toggl report*

![Untitled](Development%20Process%20a132dd5987b94adf8fc5989add9afc3f/Untitled%206.png)