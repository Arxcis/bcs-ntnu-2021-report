# Architecture

# Overview

![component-overview(1).png](Architecture%201442df162dbe45f4a423ba37d3e12363/component-overview(1).png)

Here is an overview of all the components of DID CLI's architecture. We are going to go through piece by piece.

# Components

## The Unix programming environment

![Untitled](Architecture%201442df162dbe45f4a423ba37d3e12363/Untitled.png)

The environment in which the user runs the application. The user will be able to store strings in the filesystem, and interact with applications via STDIN/STDOUT.

## DID CLI

![Untitled](Architecture%201442df162dbe45f4a423ba37d3e12363/Untitled%201.png)

DID CLI is the binary executable which the user installs on his machine. The DID CLI is the only part of the application that is visible to the user. The user runs the application by typing `did` in the command-line. The user has to make sure that the directory which the `did` -executable resides in is added to the terminals `PATH` variable.

## Config

![Untitled](Architecture%201442df162dbe45f4a423ba37d3e12363/Untitled%202.png)

The Config component is the part of the application which takes the STDIN from the user and turns it into structured data, which can be used by the rest of the application.

STDIN is parsed into a structure in Rust which looks like this:

```rust
pub struct Config {
    cmd: CMD,
}

enum CMD {
    Help,
    Init,
    Doc,
    Connect{ didname: String, did: String },
    Dids,
    Did{ didname: String },

    // DIDComm v2 messaging
    Write{ didname: String, message: String },
    Read{ dcem: String },
    Hold{ dcem: String },
    Messages,
    Message{ message_id: String },

    // DIDComm v2 + Verifiable Credentials
    IssuePassport{ didname: String },
    IssueDriversLicense{ didname: String },
    IssueTrafficAuthority{ didname: String },
    IssueLawEnforcer{ didname: String },
    Present{ didname: String, dcem: String },
    Verify{ issuer_didname: String, subject_didname: String, dcem: String },
}
```

Depending on which command the user is trying to run, one of the enum types are selected and put into the Config-struct.

## Run

![Untitled](Architecture%201442df162dbe45f4a423ba37d3e12363/Untitled%203.png)

Run takes the Config-struct and selects which command to run based on the Config.cmd variable. This can be done quite elegantly in Rust using the `match` primitive:

```rust
pub async fn run(config: Config) -> Result<String, std::io::Error> {
    match config.cmd {
        CMD::Help => help(),

        // DID
        CMD::Init => init(),
        CMD::Doc => doc(),
        CMD::Connect{ didname, did } => connect(&didname, &did),
        CMD::Dids => dids(),
        CMD::Did{ didname } => did(&didname),

        // DIDComm v2
        CMD::Write{ didname, message } => write(&didname, &message),
        CMD::Read{ dcem } => read(&dcem),
        CMD::Hold{ dcem } => hold(&dcem),
        CMD::Messages => messages(),
        CMD::Message{ message_id } => message(&message_id),

        // Verifiable Credentials
        CMD::IssuePassport{ didname } => issue("Passport", &didname).await,
        CMD::IssueLawEnforcer{ didname } => issue("LawEnforcer", &didname).await,
        CMD::IssueTrafficAuthority{ didname } => issue("TrafficAuthority", &didname).await,
        CMD::IssueDriversLicense{ didname } => issue("DriversLicense", &didname).await,
        CMD::Present{ didname, dcem } => present(&didname, &dcem).await,
        CMD::Verify{ issuer_didname, subject_didname, dcem } => verify(&issuer_didname, &subject_didname, &dcem).await,
    }
}
```

Note that all commands have different argument-signature, but identical result-signature, which makes it easy for the run-function to handle them in a general way. Some commands are async though, and need to be awaited for them before returned. Example:

```rust
issue("Passport", &didname).await
```

## Command functions

![Untitled](Architecture%201442df162dbe45f4a423ba37d3e12363/Untitled%204.png)

The simplest commands take no arguments.

```
did help
```

```rust
fn help() -> Result<String, std::io::Error>
```

But commands may be declared to take any amount of arguments. The arguments given to the function are mapped from the CLI args.

```
did read <dcem>
```

```rust
fn read(dcem: &str) -> Result<String, std::io::Error>
```

Commands  may also be declared as async as mentioned in 5.2.4 Run.

```
did present <didname> <dcem>
```

```rust
async fn present(didname: &str, dcem: &str) -> Result<String, std::io::Error>
```

As mentioned in 5.2.4, they need to be `.await`-ed, before they can be returned to the user:

```rust
return present(&didname, &dcem).await
```

## Agent local storage

![Untitled](Architecture%201442df162dbe45f4a423ba37d3e12363/Untitled%205.png)

The local storage is a simple file-based database, where data about our agent is stored. This data includes private and public keys for encryption, message history and stored did-aliases.

Here is an example of how the `.did/` folder looks after running `did init` :

```tsx
% tree .did/
.did
|-- did-names/
|    |--- did:key:z6Mkuqfe3ZXgRqqHZmTDP7egHWZCPBB6rS4EHHBouVRU8zvF
|-- dids/
|    |--- self.did
|-- messages/
|-- key.jwk

```

- **did-names/** - contain files named <did> mapping to a <did-name>
    
    ```tsx
    % cat did-names/did:key:z6Mkuqfe3ZXgRqqHZmTDP7egHWZCPBB6rS4EHHBouVRU8zvF 
    self
    ```
    
- ***dids/ -*** contain files named <did-name>.did mapping to a <did>.
    
    ```tsx
    % cat dids/self.did  
    did:key:z6Mkuqfe3ZXgRqqHZmTDP7egHWZCPBB6rS4EHHBouVRU8zvF
    ```
    
- **messages/ -** Is empty in the beginning, but will over time fill up with **.dcem**-files.
    
    *>"When persisted as a file or attached as a payload in other contexts, the file extension for **DIDComm encrypted messages** SHOULD be `dcem`, giving a globbing pattern of `.dcem`; this SHOULD be read as “Star Dot D C E M” or as “D C E M” files."*
    
    [https://identity.foundation/didcomm-messaging/spec/#didcomm-encrypted-message](https://identity.foundation/didcomm-messaging/spec/#didcomm-encrypted-message)
    

## The public/private keypair

The **.did/key.jwk**-file contains a jwk representation of an ED25519 keypair. Example:

```tsx
% cat key.jwk 
{
	"kty":"OKP",
  "crv":"Ed25519",
  "x":"5JzCcc-prZ8ZILJKAzl0_GaLWwjb6epW2kTiR6a8ytw", // Public part
  "d":"zlLjusM6Vy9cuxJ3ANFz-YhVUZ5VdMnrTsl4bHFHbsU"  // Private part
}
```

For more in-depth info about the OKP key-type, see [https://datatracker.ietf.org/doc/html/draft-ietf-jose-cfrg-curves-06#appendix-A.1](https://datatracker.ietf.org/doc/html/draft-ietf-jose-cfrg-curves-06#appendix-A.1).

The controller of this key, controls the digital Self-Sovereign-identity which is built on top of it. If this key is lost or disclosed, consider your identity compromised.

**Secure storage**

This keypair whould ideally not be stored in a cleartext file, as it currently is in DID-CLI. In a production system this keypair would be stored in a secure storage provided by the specific platform the application is running on. 

Examples of platform specific secure-storage:

- MacOS keychain - [https://support.apple.com/no-no/guide/mac-help/mchlf375f392/mac](https://support.apple.com/no-no/guide/mac-help/mchlf375f392/mac)
- Android keystore - [https://developer.android.com/training/articles/keystore](https://developer.android.com/training/articles/keystore)
- Web authentication API - [https://developer.mozilla.org/en-US/docs/Web/API/Web_Authentication_API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Authentication_API)

**Secure transmision**

It is necessary to share the jwk with other agents, to establish communication channels. When in transmit the private part of the jwk is left out, as shown below:

```tsx
% cat publickey.jwk 
{
	"kty":"OKP",
  "crv":"Ed25519",
  "x":"5JzCcc-prZ8ZILJKAzl0_GaLWwjb6epW2kTiR6a8ytw", // Public part
  // Private part left out
} 
```

# External libraries

![Untitled](Architecture%201442df162dbe45f4a423ba37d3e12363/Untitled%206.png)

The external libraries help us implement the different layers of the SSI-stack and cryptography.

## ed25519_dalek::

- **Description:** Fast and efficient Rust implementation of ed25519 key generation, signing and verification in Rust.
- **Source code:** [https://github.com/dalek-cryptography/ed25519-dalek](https://github.com/dalek-cryptography/ed25519-dalek)
- **Number of references:** 1
    
    ![Untitled](Architecture%201442df162dbe45f4a423ba37d3e12363/Untitled%207.png)
    
- **Usage:** This library is used on a single line of code which is the line that generates the private key.
    
    ```rust
    let private_key = ed25519_dalek::SecretKey::generate(&mut csprng).to_bytes();
    ```
    
    It is indirectly used by **did_key** and **ssi** as well.
    

## did_key::

- **Description:** Rust reference-implementation of the **did:key** method.
- **Source code:** [https://github.com/decentralized-identity/did-key.rs](https://github.com/decentralized-identity/did-key.rs)
- **Number of references:** 39
    
    ![Untitled](Architecture%201442df162dbe45f4a423ba37d3e12363/Untitled%208.png)
    
- **Usage:** did_key:: is used  by almost all commands and is the basis for how we talk about a DID in the codebase:
    
    ```rust
    let did = did_key::Ed25519KeyPair::from_seed(&private);
    let did_document = did.get_did_document(did_key::CONFIG_LD_PUBLIC);
    ```
    
- did_key also implements a way to create an Eliptic-Curve-Diffie-Helman (ECDH) shared secret, which didcomm_rs requires for encrypting and decrypting messages:
    
    ```rust
    use did_key::Ecdh;
    use did_key::DIDCore;
    
    // 1. Get keypairs
    let from_key: did_key::Ed25519KeyPair = getKeypair()
    let to_key: did_key::Ed25519KeyPair = getKeypair()
    
    // 2. Map Ed25519 -> x25519
    let from_key: x25519::X25519KeyPair = from_key.get_x25519();
    let to_key: x25519::X25519KeyPair = to_key.get_x25519();
    
    // 3. Make shared ECDH-secret (from -> to)
    let shared_secret: Vec<u8> = from_key.key_exchange(&to_key);
    ```
    

## didcomm_rs::

- **Description:** Rust reference-implementation of the DIDComm v2 spec.
- **Source code:** [https://github.com/decentralized-identity/didcomm-rs](https://github.com/decentralized-identity/didcomm-rs)
- **Number of references:** 6
    
    ![Untitled](Architecture%201442df162dbe45f4a423ba37d3e12363/Untitled%209.png)
    
- **Usage:** The number of references to **didcomm_rs** is kept pretty low, because the usage is hidden behind the two functions encrypt_didcomm() and decrypt_didcomm():
    
    ```rust
    // Create DIDComm message
    let dcpm = didcomm_rs::Message::new()
      .from(&from_did)
      .to(&to_vec[..])
      .timed(Some(3600))
      .body(message.as_bytes())
      .as_jwe(&didcomm_rs::crypto::CryptoAlgorithm::XC20P);
    
    // Encrypt DIDComm message
    let dcem = dcpm
      .seal(&shared_secret)
      .unwrap();
    
    // Decrypt DIDComm message
    let message = didcomm_rs::Message::receive(
    	  dcem, Some(&shared_secret), None);
    ```
    

## ssi::

- **Description:** Core library for decentralized identity
- **Source code:** [https://github.com/spruceid/ssi](https://github.com/spruceid/ssi)
- **Number of references:** 28
- **Usage:** Mainly used to implement **issue**, **hold**, **present** and **verify** Verifiable Credentials. Here is an example of issuing a VC:
    
    ```rust
    let vc = serde_json::json!({
            "@context": [
                "https://www.w3.org/2018/credentials/v1",
            ],
            "type": ["VerifiableCredential", credential_type],
            "issuer": issuer_doc.id,
            "issuanceDate": ssi::ldp::now_ms(),
            "credentialSubject": {
                "id": subject_doc.id
            }
        });
    
    // Setup proof options with verification method from issuer did doc 
    // https://www.w3.org/TR/did-core/#assertion
    let mut vc: ssi::vc::Credential = serde_json::from_value(vc).unwrap();
    let mut proof_options = ssi::vc::LinkedDataProofOptions::default();
    let verification_method = issuer_doc.assertion_method.unwrap()[0].clone();
    proof_options.verification_method = Some(verification_method);
    proof_options.proof_purpose = Some(ssi::vc::ProofPurpose::AssertionMethod);
    
    // Generate proof, using issuer jwk + proof options
    let proof = vc.generate_proof(&issuer_jwk, &proof_options).await.unwrap();
    vc.add_proof(proof);
    ```
    

# Sequence diagram

![Untitled](Architecture%201442df162dbe45f4a423ba37d3e12363/Untitled%2010.png)

This sequence diagrams shows how data flows when 2 people - Alice and Bob - are using DID-CLI. Alices side is more detailed to show how data flows inside the DID-CLI and to external libraries, while Bobs side only shows the interactions with the CLI.

```bash
https://sequencediagram.org/index.html#initialData=title%20Issuing%20a%20VC%20to%20Bob%0A%0A%0Aparticipant%20Bob%20DID-CLI%0Aactor%20Bob%0A%0Aparticipant%20File%0A%0Aactor%20Alice%0Aparticipant%20Alice%20DID-CLI%0Aparticipant%20ed25519_dalek%0Aparticipant%20did_key%0Aparticipant%20ssi%0Aparticipant%20didcomm_rs%0A%0Aentryspacing%200.9%0ABob-%3EBob%20DID-CLI%3A%20did%20init%0ABob%3C%3C--Bob%20DID-CLI%3A%20(did)%0AFile%3C-Bob%3A%20Write(did)%0AAlice-%3EFile%3A%20Read(did)%0AAlice%3C%3C--File%3A%20(Bobs%20did)%0AAlice-%3EAlice%20DID-CLI%3A%20did%20init%0AAlice%20DID-CLI-%3Eed25519_dalek%3A%20Create%20private%20jwk%0AAlice%20DID-CLI%3C%3C--ed25519_dalek%3A%20(Private%20jwk)%0AAlice%3C%3C--Alice%20DID-CLI%3A%20(Alices%20did)%0AAlice-%3EAlice%20DID-CLI%3A%20Issue(Passport%20to%20Bobs%20did)%0AAlice%20DID-CLI-%3Edid_key%3A%20Init%20Alice%20DID(Alice%20private%20jwk)%0AAlice%20DID-CLI%3C%3C--did_key%3A%20(Alice%20DID)%0AAlice%20DID-CLI-%3Edid_key%3A%20Init%20Bob%20DID(Bobs%20did)%0AAlice%20DID-CLI%3C%3C--did_key%3A%20(Bob%20DID)%0A%0A%0AAlice%20DID-CLI-%3Essi%3A%20Issue%20Verifiable%20Credential%20(from%3A%20Alice%20DID%2C%20to%3A%20Bob%20DID)%0AAlice%20DID-CLI%3C%3C--ssi%3A%20(Signed%20verifiable%20credential)%0A%0AAlice%20DID-CLI-%3Edidcomm_rs%3A%20Create%20DIDComm-message(from%3A%20Alice%20DID%2C%20to%3A%20Bob%20DID%2C%20message%3A%20VC)%20%20%0A%0AAlice%20DID-CLI%3C%3C--didcomm_rs%3A%20(dcem)%0AAlice%3C%3C--Alice%20DID-CLI%3A%20(dcem)%0A%0AAlice-%3E%3EFile%3A%20Write%20(dcem)%0AFile%3C-Bob%3A%20Read(dcem)%0AFile--%3E%3EBob%3A%20(dcem)%0ABob-%3EBob%20DID-CLI%3A%20Hold(dcem)%0ABob%3C%3C--Bob%20DID-CLI%3A%20(dcem)%0ABob-%3EBob%20DID-CLI%3A%20Read(dcem)%0ABob%3C%3C--Bob%20DID-CLI%3A%20(vc%20Passport)%0A
```

# Build, run, install

## System requirements

To build the application you need to have the latest rust toolchain installed. DID-CLI is known to work with at least Rust/Cargo version 1.56:

```bash
% rustc --version
rustc 1.56.1 (59eed8a2a 2021-11-01)
% cargo --version
cargo 1.56.0 (4ed5d137b 2021-10-04)
```

An easy and recommended way to install the Rust toolchain is to use `rustup`:

```bash
% curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

[https://rustup.rs/](https://rustup.rs/)

## Build

Once you have gone through the installation process and restarted your terminal, you should be able to build the debug version of DID-CLI:

```bash
% cargo build
% tree target/debug -L 1  
target/debug
|-- build
|-- deps
|-- did            # <--- Debug executeable
|-- did.d
|-- examples
|-- incremental
|-- libdid.d
|-- libdid.rlib
```

To build the optimised release variant, do:

```bash
% cargo build --release
% tree target/release -L 1
target/release
|-- build
|-- deps
|-- did          # <--- Release executeable
|-- did.d
|-- examples
|-- incremental
|-- libdid.d
|-- libdid.rlib
```

## Run

To run the built executeable, you may do

```bash
% ./target/debug/did
```

When developing, we may want to build and run the in a single step. In that case we may only do.

```bash
% cargo run
% cargo run --release
```

## Installation

To make it simple to access DID-CLI anywhere on our system, you may choose to install the executable in a folder which is in our PATH variable.

```bash
cp target/debug/did ~/bin            # Install for the currently signed in user
cp target/debug/did /usr/local/bin   # Install for all users

# After this you may do independent of your working directory
did <command>
```