# DID CLI Bachelor

[Progress](DID%20CLI%20Bachelor%2066adad5a8c7e46d5a45b82031f9a87b4/Progress%200114e370ae274626accfb762f4a0142a.csv)

[Introduction](DID%20CLI%20Bachelor%2066adad5a8c7e46d5a45b82031f9a87b4/Introduction%2099c57a51162f4f85bc7ec35261236693.md)

[Development Process](DID%20CLI%20Bachelor%2066adad5a8c7e46d5a45b82031f9a87b4/Development%20Process%20a132dd5987b94adf8fc5989add9afc3f.md)

[Functional Requirements](DID%20CLI%20Bachelor%2066adad5a8c7e46d5a45b82031f9a87b4/Functional%20Requirements%20b66771c223f2424c9b1ba3285a2ba469.md)

[User Interface](DID%20CLI%20Bachelor%2066adad5a8c7e46d5a45b82031f9a87b4/User%20Interface%20f8759a9462b24d5f95cf6123d68b89ea.md)

[Architecture](DID%20CLI%20Bachelor%2066adad5a8c7e46d5a45b82031f9a87b4/Architecture%201442df162dbe45f4a423ba37d3e12363.md)

[Results](DID%20CLI%20Bachelor%2066adad5a8c7e46d5a45b82031f9a87b4/Results%20e65c0fdb756c4f16bc6b3034b8525d1e.md)

[Discussion](DID%20CLI%20Bachelor%2066adad5a8c7e46d5a45b82031f9a87b4/Discussion%20586019af24b74250a0b790064d7f4bb1.md)

[Conclusion](DID%20CLI%20Bachelor%2066adad5a8c7e46d5a45b82031f9a87b4/Conclusion%207e4806d9d04e4bad9a17fd829aeb1786.md)